<?php /* Smarty version Smarty-3.1-DEV, created on 2016-04-26 12:57:08
         compiled from "D:\workspace\project_name\app_name\ApplicationRoot\views\templates\Message.tpl" */ ?>
<?php /*%%SmartyHeaderCode:30973571ee7146b67a7-86284579%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f1bdcec6218d634249c4c1f57158294de57d8741' => 
    array (
      0 => 'D:\\workspace\\project_name\\app_name\\ApplicationRoot\\views\\templates\\Message.tpl',
      1 => 1461643028,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '30973571ee7146b67a7-86284579',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'err_msg' => 0,
    'error' => 0,
    'info_msg' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_571ee714759447_38208813',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_571ee714759447_38208813')) {function content_571ee714759447_38208813($_smarty_tpl) {?><!--#####メッセージ出力ここから#####-->
<?php if (count($_smarty_tpl->tpl_vars['err_msg']->value)!=0){?>
      <div class="alert alert-dismissable alert-danger"><i class="fa fa-ban"></i>
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><b>エラー</b></h4>
        <?php  $_smarty_tpl->tpl_vars['error'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['error']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['err_msg']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['error']->key => $_smarty_tpl->tpl_vars['error']->value){
$_smarty_tpl->tpl_vars['error']->_loop = true;
?>
        <p>[<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['error']->value['title'], ENT_QUOTES, 'UTF-8', true);?>
] <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['error']->value['message'], ENT_QUOTES, 'UTF-8', true);?>
</p>
        <?php } ?>
      </div>
<?php }elseif($_smarty_tpl->tpl_vars['info_msg']->value!=''){?>
      <div class="alert alert-dismissable alert-success"><i class="fa fa-check"></i>
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><b>完了</b></h4>
        <p><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['info_msg']->value, ENT_QUOTES, 'UTF-8', true);?>
</p>
      </div>
<?php }?>
<!--#####メッセージ出力ここまで#####-->
<?php }} ?>