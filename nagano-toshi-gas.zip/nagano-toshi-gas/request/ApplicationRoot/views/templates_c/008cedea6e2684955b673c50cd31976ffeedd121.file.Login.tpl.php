<?php /* Smarty version Smarty-3.1-DEV, created on 2016-11-21 13:51:40
         compiled from "D:\workspace\nagano-toshi-gas\ApplicationRoot\views\templates\Login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:727858327d5c7e4099-36156665%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '008cedea6e2684955b673c50cd31976ffeedd121' => 
    array (
      0 => 'D:\\workspace\\nagano-toshi-gas\\ApplicationRoot\\views\\templates\\Login.tpl',
      1 => 1461638860,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '727858327d5c7e4099-36156665',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'doc_root' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_58327d5cbe6b90_24779971',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58327d5cbe6b90_24779971')) {function content_58327d5cbe6b90_24779971($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<body>
<div class="form-box">
<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

  <div class="header"><img src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['doc_root']->value, ENT_QUOTES, 'UTF-8', true);?>
img/logo.png" width="200" height="50" alt=""/></div>
  <form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
    <div class="body bg-gray">
      <div class="form-group">
        <input type="text" name="user_id" class="form-control" placeholder="ユーザーID" value="" />
      </div>
      <div class="form-group">
        <input type="password" name="password" class="form-control" placeholder="パスワード" />
      </div>
    </div>
    <div class="footer">
      <button onclick="submit_c('login', 'login'); return false" class="btn btn-primary btn-block">ログイン</button>
    </div>
  </form>
  <br>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("PageEnd.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }} ?>