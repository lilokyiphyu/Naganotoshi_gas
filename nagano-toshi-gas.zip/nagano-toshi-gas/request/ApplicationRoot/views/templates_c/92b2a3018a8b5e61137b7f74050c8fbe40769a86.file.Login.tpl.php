<?php /* Smarty version Smarty-3.1-DEV, created on 2016-04-26 12:55:26
         compiled from "D:\workspace\project_name\app_name\ApplicationRoot\views\templates\Login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10385571ee6ae0cf701-20028263%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '92b2a3018a8b5e61137b7f74050c8fbe40769a86' => 
    array (
      0 => 'D:\\workspace\\project_name\\app_name\\ApplicationRoot\\views\\templates\\Login.tpl',
      1 => 1461638860,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10385571ee6ae0cf701-20028263',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'doc_root' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_571ee6ae155554_49979277',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_571ee6ae155554_49979277')) {function content_571ee6ae155554_49979277($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<body>
<div class="form-box">
<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

  <div class="header"><img src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['doc_root']->value, ENT_QUOTES, 'UTF-8', true);?>
img/logo.png" width="200" height="50" alt=""/></div>
  <form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
    <div class="body bg-gray">
      <div class="form-group">
        <input type="text" name="user_id" class="form-control" placeholder="ユーザーID" value="" />
      </div>
      <div class="form-group">
        <input type="password" name="password" class="form-control" placeholder="パスワード" />
      </div>
    </div>
    <div class="footer">
      <button onclick="submit_c('login', 'login'); return false" class="btn btn-primary btn-block">ログイン</button>
    </div>
  </form>
  <br>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("PageEnd.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }} ?>