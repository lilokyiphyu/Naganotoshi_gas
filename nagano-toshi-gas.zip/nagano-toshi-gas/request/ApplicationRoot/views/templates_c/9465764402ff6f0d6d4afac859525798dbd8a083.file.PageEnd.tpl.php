<?php /* Smarty version Smarty-3.1-DEV, created on 2016-04-26 12:57:08
         compiled from "D:\workspace\project_name\app_name\ApplicationRoot\views\templates\PageEnd.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18930571ee714b91d78-75684036%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9465764402ff6f0d6d4afac859525798dbd8a083' => 
    array (
      0 => 'D:\\workspace\\project_name\\app_name\\ApplicationRoot\\views\\templates\\PageEnd.tpl',
      1 => 1461638766,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18930571ee714b91d78-75684036',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_571ee714ba3fd8_63551426',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_571ee714ba3fd8_63551426')) {function content_571ee714ba3fd8_63551426($_smarty_tpl) {?></body>
</html>
<?php }} ?>