<?php /* Smarty version Smarty-3.1-DEV, created on 2016-04-26 12:52:43
         compiled from "D:\workspace\project_name\app_name\ApplicationRoot\views\templates\PageFooter.tpl" */ ?>
<?php /*%%SmartyHeaderCode:449571ee5ea97a9b2-24920960%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1bb863d2d32d0094d3eb3f3c3e7502bced2ac752' => 
    array (
      0 => 'D:\\workspace\\project_name\\app_name\\ApplicationRoot\\views\\templates\\PageFooter.tpl',
      1 => 1461642762,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '449571ee5ea97a9b2-24920960',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_571ee5ea9a9799_26421208',
  'variables' => 
  array (
    'doc_root' => 0,
    'site_name' => 0,
    'controller_name' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_571ee5ea9a9799_26421208')) {function content_571ee5ea9a9799_26421208($_smarty_tpl) {?>      <div class="copyright">Copyright &copy; 2014 goodbee.co.jp All Rights Reserved.</div>
    </section>
  </aside>
</div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content"></div>
  </div>
</div>
<script src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['doc_root']->value, ENT_QUOTES, 'UTF-8', true);?>
js/app.js" type="text/javascript"></script>
<script type="text/javascript">
	var g_site_name = '<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['site_name']->value, ENT_QUOTES, 'UTF-8', true);?>
';
	var g_controllerName = '<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['controller_name']->value, ENT_QUOTES, 'UTF-8', true);?>
';
</script>
<?php }} ?>