<?php /* Smarty version Smarty-3.1-DEV, created on 2016-11-21 13:51:40
         compiled from "D:\workspace\nagano-toshi-gas\ApplicationRoot\views\templates\PageHeader.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2023958327d5ccf11b2-48928700%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd2f63b347396ccbc149070aca50d15508b601be5' => 
    array (
      0 => 'D:\\workspace\\nagano-toshi-gas\\ApplicationRoot\\views\\templates\\PageHeader.tpl',
      1 => 1461638752,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2023958327d5ccf11b2-48928700',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'doc_root' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_58327d5cd0e050_08631214',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58327d5cd0e050_08631214')) {function content_58327d5cd0e050_08631214($_smarty_tpl) {?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>タイトル</title>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<link href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['doc_root']->value, ENT_QUOTES, 'UTF-8', true);?>
css/xxxxx.css" rel="stylesheet" type="text/css" />
<link href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['doc_root']->value, ENT_QUOTES, 'UTF-8', true);?>
favicon.ico" rel="shortcut icon">
<!--[if lt IE 9]>
<style>.breadcrumb > li {float: left;}</style>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->
</head>
  <?php }} ?>