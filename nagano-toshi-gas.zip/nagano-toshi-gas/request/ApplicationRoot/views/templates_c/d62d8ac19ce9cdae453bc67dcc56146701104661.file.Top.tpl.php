<?php /* Smarty version Smarty-3.1-DEV, created on 2016-04-26 12:57:48
         compiled from "D:\workspace\project_name\app_name\ApplicationRoot\views\templates\Top.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17823571ee73ca06a61-54360648%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd62d8ac19ce9cdae453bc67dcc56146701104661' => 
    array (
      0 => 'D:\\workspace\\project_name\\app_name\\ApplicationRoot\\views\\templates\\Top.tpl',
      1 => 1461639498,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17823571ee73ca06a61-54360648',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'doc_root' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_571ee73ca94722_75041629',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_571ee73ca94722_75041629')) {function content_571ee73ca94722_75041629($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<body>
<div class="form-box">
<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

  <div class="header"><img src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['doc_root']->value, ENT_QUOTES, 'UTF-8', true);?>
img/logo.png" width="200" height="50" alt=""/></div>
  <form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
    <p>TOP画面</p>
  </form>
  <br>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("PageEnd.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }} ?>