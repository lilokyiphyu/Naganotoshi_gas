<?php


require_once 'framework/ControllerAbstract.php';
require_once 'helper/SessionManager.php';
require_once 'Exception.php';

class TopController extends Framework_ControllerAbstract
{
	protected function _getValidationSetting() {
	}

	public function indexAction()
	{
		$this->_render('Top');
	}
}
