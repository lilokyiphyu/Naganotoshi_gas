<?php

/**
 * @file HtmlTagData.class.php
 * @brief HTMLタグ生成データ定義
 * HTMLタグ生成データを定義する
 * @author tac@goodbee.jp
 * @date 2010/02
 * @version 1.0
 *
 */

/**
 * @class HTMLタグ生成データ定義クラス
 * HTMLタグ生成データを一括管理する
 *
 */
class HtmlTagData {

}

?>
