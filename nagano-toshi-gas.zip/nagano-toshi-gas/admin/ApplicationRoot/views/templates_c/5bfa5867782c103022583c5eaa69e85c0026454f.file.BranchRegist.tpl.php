<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-13 15:48:23
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\BranchRegist.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15157584759b8d89ad5-25810914%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5bfa5867782c103022583c5eaa69e85c0026454f' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\BranchRegist.tpl',
      1 => 1481611693,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15157584759b8d89ad5-25810914',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_584759b8de7a90_52055342',
  'variables' => 
  array (
    'branch' => 0,
    'id' => 0,
    'name' => 0,
    'branch_number1' => 0,
    'branch_number2' => 0,
    'admin_name' => 0,
    'email' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_584759b8de7a90_52055342')) {function content_584759b8de7a90_52055342($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			<div class="wrapper">
				<h2>支店新規登録</h2>
				<div class="col12">
					<div class="block">
						<div class="form-group">
							<table cellspacing="0" class="vtable">
								<tbody>
									<tr>
										<td><input name="id" type="hidden" class="w460" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['branch']->value['id'], ENT_QUOTES, 'UTF-8', true);?>
"></td>
									</tr>
									<tr>
										<input type="hidden" name="id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['id']->value, ENT_QUOTES, 'UTF-8', true);?>
">
										<th scope="row"><span class="must">必須</span>支店名</th>
										<td><input name="name" type="text" class="w460" placeholder="支店名" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['name']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
									</tr>
									<tr>
										<th scope="row"><span class="must">必須</span>契約番号一桁目1</th>
										<td><input name="branch_number1" type="text" class="w460 imeoff" placeholder="契約番号一桁目1" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['branch_number1']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
									</tr>
									<tr>
										<th scope="row">契約番号一桁目2</th>
										<td><input name="branch_number2" type="text" class="w460 imeoff" placeholder="契約番号一桁目2" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['branch_number2']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
									</tr>
									<tr>
										<th scope="row"><span class="must">必須</span>管理者名</th>
										<td><input name="admin_name" type="text" class="w460" placeholder="管理者名" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['admin_name']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
									</tr>
									<tr>
										<th scope="row"><span class="must">必須</span>管理者メールアドレス</th>
										<td><input name="email" type="text" class="w460" placeholder="管理者メールアドレス" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['email']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>

				<nav class="submitbtnarea">
					<ul class="btnarea-left">
						<li>
							<button type="button"><i class="fa fa-chevron-left"></i> 戻る</button>
						</li>
					</ul>

					<ul>
						<li>
							<a href="#" class="btn btn-submit" onclick="javascript:submit_a_Confirm('regist'); return false;"><i class="fa fa-check" aria-hidden="true"></i> 登録</a>
						</li>
					</ul>
				</nav>

			</div><!--wrapper-->
</from>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }} ?>