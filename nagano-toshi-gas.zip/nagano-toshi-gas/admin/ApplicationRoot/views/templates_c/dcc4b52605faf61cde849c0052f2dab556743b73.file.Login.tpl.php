<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-13 11:56:23
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\Login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:24025841091aec8944-34496423%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dcc4b52605faf61cde849c0052f2dab556743b73' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\Login.tpl',
      1 => 1481597782,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '24025841091aec8944-34496423',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_5841091b034ad8_79785303',
  'variables' => 
  array (
    'doc_root' => 0,
    'user_id' => 0,
    'password' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5841091b034ad8_79785303')) {function content_5841091b034ad8_79785303($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("Pager.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			<div class="login">
				<h2><img src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['doc_root']->value, ENT_QUOTES, 'UTF-8', true);?>
img/logo.png" width="143" height="50" alt="長野都市ガス"></h2>
					<form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
						<div class="block">
							<div class="error-area">
								ログインIDは必須入力項目です。<br>
								パスワードは必須入力項目です。
							</div>

						<div class="form-group">
							<table cellspacing="0" class="vtable">
								<tbody>
									<tr>
										<th scope="row">ログインID</th>
										<td><input name="user_id" type="text" autofocus class="w240 imeoff" placeholder="ログインID" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['user_id']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
									</tr>
									<tr>
										<th scope="row">パスワード</th>
										<td><input name="password" type="password" class="w240 imeoff" placeholder="パスワード" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['password']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
									</tr>
								</tbody>
							</table>
						</div>
						</div>
						<nav class="submitbtnarea">
							<ul>
								<li><a href="" class="btn btn-next" onclick="submit_c('login', 'login','top-page'); return false" ><i class="fa fa-unlock-alt"  ></i> ログイン</a></li>
							</ul>
						</nav>
			</div>
</form>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>