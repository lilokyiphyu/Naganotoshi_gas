<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-02 14:17:46
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\Message.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7804584103fa1696e9-85229480%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6cfd1092b92c72b4046519c9144452148d44fdc7' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\Message.tpl',
      1 => 1480051988,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7804584103fa1696e9-85229480',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'err_msg' => 0,
    'error' => 0,
    'info_msg' => 0,
    'info_title' => 0,
    'alert_msg' => 0,
    'alert_title' => 0,
    'success_msg' => 0,
    'success_title' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_584103fa2c1c57_16853954',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_584103fa2c1c57_16853954')) {function content_584103fa2c1c57_16853954($_smarty_tpl) {?><?php if (count($_smarty_tpl->tpl_vars['err_msg']->value)!=0){?>
  <div class="alert alert-danger alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-ban"></i> エラー</h4>
    <?php  $_smarty_tpl->tpl_vars['error'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['error']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['err_msg']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['error']->key => $_smarty_tpl->tpl_vars['error']->value){
$_smarty_tpl->tpl_vars['error']->_loop = true;
?>
    <p>[<?php echo $_smarty_tpl->tpl_vars['error']->value['title'];?>
] <?php echo $_smarty_tpl->tpl_vars['error']->value['message'];?>
</p>
    <?php } ?>
  </div>
<?php }elseif($_smarty_tpl->tpl_vars['info_msg']->value!=''){?>
  <div class="alert alert-info alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-info"></i> <?php echo $_smarty_tpl->tpl_vars['info_title']->value;?>
</h4>
    <p><?php echo $_smarty_tpl->tpl_vars['info_msg']->value;?>
</p>
  </div>
<?php }elseif($_smarty_tpl->tpl_vars['alert_msg']->value!=''){?>
  <div class="alert alert-warning alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-warning"></i> <?php echo $_smarty_tpl->tpl_vars['alert_title']->value;?>
</h4>
    <p><?php echo $_smarty_tpl->tpl_vars['alert_msg']->value;?>
</p>
  </div>
<?php }elseif($_smarty_tpl->tpl_vars['success_msg']->value!=''){?>
  <div class="alert alert-success alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4>  <i class="icon fa fa-check"></i> <?php echo $_smarty_tpl->tpl_vars['success_title']->value;?>
</h4>
    <p><?php echo $_smarty_tpl->tpl_vars['success_msg']->value;?>
</p>
  </div>
<?php }?>
<?php }} ?>