<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-08 13:27:48
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\HolidayList.tpl" */ ?>
<?php /*%%SmartyHeaderCode:200765841099a334bf6-71886299%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f11876463e33ec3566686a0696690dcc6cbf9dd9' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\HolidayList.tpl',
      1 => 1481171263,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '200765841099a334bf6-71886299',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_5841099a393358_17952504',
  'variables' => 
  array (
    'name' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5841099a393358_17952504')) {function content_5841099a393358_17952504($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data" class="form-horizontal">
<div class="wrapper">
		<h2>祝日設定</h2>
	<div class="col12">
		<div class="block">
			<div class="form-group">
				<table cellspacing="0" class="vtable">
					<tbody>
						<tr>
							<th scope="row">祝日</th>
							<td>
								<textarea name="name" rows="8" placeholder="祝日" data-max="2000" data-min="1" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['name']->value, ENT_QUOTES, 'UTF-8', true);?>
"></textarea>
								<span class="textlength"></span>
								<p class="asterisk">2017/01/01の形式で一行づつ入力してください。</p>
							</td>
						</tr>
					 </tbody>
				</table>
			</div>
		</div>
	</div>

	<nav class="submitbtnarea">
		<ul class="btnarea-left">
			<li>
				<button type="button" ><i class="fa fa-chevron-left" aria-hidden="true"></i> 戻る</button>
			</li>
			</ul>
		<ul>
			<li><a href="#" class="btn btn-next" onclick="submit_c_Confirm('holiday-list', 'edit'); return false;"><i class="fa fa-repeat" aria-hidden="true"></i> 更新</a></li>
		</ul>
	</nav>
</div><!--wrapper-->
</form>

<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>