<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-05 11:15:06
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\DocumentList.tpl" */ ?>
<?php /*%%SmartyHeaderCode:48245844cd9e6fee14-52252826%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'edef3edddd69723903a1ce1e651fc27c3385637a' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\DocumentList.tpl',
      1 => 1480904105,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '48245844cd9e6fee14-52252826',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_5844cd9e72f511_32372504',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5844cd9e72f511_32372504')) {function content_5844cd9e72f511_32372504($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<div class="container">
<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<p>This is Document Page</p>
</div><!--container--->
</form>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>