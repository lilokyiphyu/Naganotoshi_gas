<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-07 14:42:14
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\UserRegist.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14048584757702fb542-99880816%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0264bc1cb97b2086185610f7f8a19df5484f8473' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\UserRegist.tpl',
      1 => 1481089294,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14048584757702fb542-99880816',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_5847577036c3c0_93279634',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5847577036c3c0_93279634')) {function content_5847577036c3c0_93279634($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('title'=>"顧客新規登録",'class'=>6), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
<div class="wrapper">
		<h2>ユーザー新規登録</h2>
	<div class="col12">
		<div class="block">
			<div class="info-area">infoメッセージ</div>
			<div class="form-group">
				<table cellspacing="0" class="vtable">
					<tbody>
						<tr>
							<th scope="row"><span class="must">必須</span>支店</th>
							<td>
							<span class="select">

							<select name="xxx" class="w460">
								<option value="1" selected>東信支店</option>
								<option value="2">東信支店</option>
								<option value="3">東信支店</option>
							</select>
							</span>
							</td>
						 </tr>

						 <tr>
							<th scope="row">支店</th>
							<td><div class="readonly">東信支店 //支店管理者の場合</div></td>
						 </tr>
						<tr>
							<th scope="row"><span class="must">必須</span>メールアドレス</th>
							<td><input name="xxx" type="text" class="w460 imeoff" placeholder="メールアドレス" value=""></td>
 						</tr>
			</div>
			</div>
	</div>
	<nav class="submitbtnarea">
		<ul class="btnarea-left">
			<li>
				<button type="button"><i class="fa fa-chevron-left"></i> 戻る</button>
			</li>
		</ul>
		<ul>
			<li><a href="#" class="btn btn-submit"><i class="fa fa-check" aria-hidden="true"></i> 登録</a></li>
		</ul>
	</nav>
	<p class="endnote">登録するとパスワードがメールアドレスに送信されます。</p>

</div><!--wrapper-->
</from>

<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }} ?>