<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-13 12:50:07
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\BranchList.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1897858476101509317-25486384%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1acc0e23d36c213c1400d679d3b1393e19d7227c' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\BranchList.tpl',
      1 => 1481597094,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1897858476101509317-25486384',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_584761015b2053_21243032',
  'variables' => 
  array (
    'branch_list' => 0,
    'branch' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_584761015b2053_21243032')) {function content_584761015b2053_21243032($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			<div class="wrapper">
					<nav class="titlebtnarea">
					<ul class="btnarea-right">
						<li>
							<a href="#" class="btn btn-sm btn-submit" onclick="javascript:submit_c('branch-regist'); return false;"><i class="fa fa-plus" aria-hidden="true"></i>新規作成</a>
						</li>
					</ul>
					</nav>
					<h2>支店一覧</h2>
						<div class="col12">
							<div class="block">
								<table cellspacing="0" class="htable">
									<thead>
										<tr>
											<th width="" scope="col">支店名</th>
											<th width="" scope="col">管理者名</th>
											<th width="" scope="col">管理者メールアドレス</th>
											<th scope="col">&nbsp;</th>
										</tr>
									</thead>
									<tbody>
									<?php  $_smarty_tpl->tpl_vars['branch'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['branch']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['branch_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['branch']->key => $_smarty_tpl->tpl_vars['branch']->value){
$_smarty_tpl->tpl_vars['branch']->_loop = true;
?>
										<tr>
											<td class="name"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['branch']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
</td>
											<td class="admin_name"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['branch']->value['admin_name'], ENT_QUOTES, 'UTF-8', true);?>
</td>
											<td class="email"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['branch']->value['email'], ENT_QUOTES, 'UTF-8', true);?>
</td>
											<td class="btncel"><a href="#" class="btn btn-sm btn-next" onclick="JavaScript:submit_c('branch-edit', 'index', 'id', <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['branch']->value['id'], ENT_QUOTES, 'UTF-8', true);?>
); return false;"><i class="fa fa-pencil" aria-hidden="true"></i> 編集</a></td>
										</tr>
									<?php } ?>
									</tbody>
									</table>
							</div>
						</div>
						<nav class="submitbtnarea">
							<ul class="btnarea-left">
								<li>
									<button type="button"><i class="fa fa-chevron-left" aria-hidden="true"></i> 戻る</button>
								</li>
							</ul>
						</nav>
			</div>

</form>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>