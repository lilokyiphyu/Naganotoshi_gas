<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-07 11:14:02
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\OfficeEdit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:138585847706ae069c4-58376396%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dc3a8844502982e2a1fbfcc7905e282a8aecb24a' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\OfficeEdit.tpl',
      1 => 1481076267,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '138585847706ae069c4-58376396',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'name' => 0,
    'branch_number1' => 0,
    'branch_number2' => 0,
    'admin_name' => 0,
    'email' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_5847706ae64cc0_19193147',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5847706ae64cc0_19193147')) {function content_5847706ae64cc0_19193147($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
<div class="wrapper">
	<h2>支店編集</h2>
	<div class="col12">
		<div class="block">
			<div class="form-group">
				<table cellspacing="0" class="vtable">
				<tbody>
					<tr>
						 <th scope="row"><span class="must">必須</span>支店名</th>
						 <td><input name="name" type="text" class="w460" placeholder="支店名" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['name']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
					</tr>

					<tr>
						<th scope="row"><span class="must">必須</span>契約番号一桁目1</th>
						<td><input name="branch_number1" type="text" class="w460 imeoff" placeholder="契約番号一桁目1" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['branch_number1']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
					</tr>
					<tr>
						<th scope="row">契約番号一桁目2</th>
						<td><input name="branch_number2" type="text" class="w460 imeoff" placeholder="契約番号一桁目2" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['branch_number2']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
					</tr>

					<tr>
						<th scope="row"><span class="must">必須</span>管理者名</th>
						<td><input name="admin_name	" type="text" class="w460 imeoff" placeholder="管理者名" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['admin_name']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
					</tr>

					<tr>
						<th scope="row"><span class="must">必須</span>管理者メールアドレス</th>
						<td><input name="email" type="text" class="w460 imeoff" placeholder="管理者メールアドレス" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['email']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
					</tr>

				</tbody>
				</table>
			</div>
		</div>
	</div>
	<nav class="submitbtnarea">
		<ul class="btnarea-left">
			<li>
				<button type="button"><i class="fa fa-chevron-left"></i> 戻る</button>
			</li>
		</ul>
		<ul>
			<li><a href="#" class="btn btn-next" onclick="submit_c_Confirm('branch-edit', 'edit'); return false;"><i class="fa fa-repeat" aria-hidden="true"></i> 更新</a></li>
			<li><a href="#" class="btn btn-default" onclick="javascript:submit_c('password-edit'); return false;""><i class="fa fa-paper-plane" aria-hidden="true"></i> パスワードリセット</a></li>
			<li><a href="#" class="btn btn-del" onclick="submit_a_delConfirm('delete'); return false;"><i class="fa fa-trash" aria-hidden="true"></i> 削除</a></li>
		</ul>
	</nav>
	<p class="endnote">パスワードリセットを行うと、初期パスワードがメールアドレスに送信されます。</p>

</div><!--wrapper-->
</form>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>