<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-14 15:32:16
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\PageNavi.tpl" */ ?>
<?php /*%%SmartyHeaderCode:367584103f9902842-15845761%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fa623768198457f4d45f161769aa3f654acb3a89' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\PageNavi.tpl',
      1 => 1481697086,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '367584103f9902842-15845761',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_584103f9af2557_85956981',
  'variables' => 
  array (
    'doc_root' => 0,
    'class' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_584103f9af2557_85956981')) {function content_584103f9af2557_85956981($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<header>
<div class="maxwidth clearfix">
		<h1><a href="#"><img src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['doc_root']->value, ENT_QUOTES, 'UTF-8', true);?>
img/logo.png" alt="長野都市ガス" height="50" width="143"></a></h1>
		<nav class="menu">
				<ul>
					<?php if ($_SESSION['AUTHORITY']==0||$_SESSION['AUTHORITY']==1){?>
					<li><a href="#" class="active" onClick="JavaScript:submit_c('request-all'); return false;">全受付</a>
					<?php }?>
				<ul class="adminmenu">
					<li><a href="#"><i class="fa fa-file-o" aria-hidden="true"></i> 未発行のみ</a></li>
					<li><a href="#"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> 発行済のみ</a></li>
				</ul>
					</li>
					<?php if ($_SESSION['AUTHORITY']==0||$_SESSION['AUTHORITY']==1){?>
	 			 	<li><a href="#" onClick="JavaScript:submit_c('request-open'); return false;">開栓受付</a>
	 				 <?php }?>
				<ul class="adminmenu">
					<li><a href="#"><i class="fa fa-file-o" aria-hidden="true"></i> 未発行のみ</a></li>
					<li><a href="#"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> 発行済のみ</a></li>
				</ul>
				</li>
					<li<?php if ($_smarty_tpl->tpl_vars['class']->value==1){?> class="active"<?php }?>>
					<li><a href="#" onClick="JavaScript:submit_c('request-close'); return false;">閉栓受付</a>
				<ul class="adminmenu">
					<li><a href="#"><i class="fa fa-file-o" aria-hidden="true"></i> 未発行のみ</a></li>
					<li><a href="#"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> 発行済のみ</a></li>
				</ul>
				</li>
				<li<?php if ($_smarty_tpl->tpl_vars['class']->value==2){?> class="active"<?php }?>>
				<li><a href="#" onClick="JavaScript:submit_c('request-maintenance'); return false;">安点日時変更受付</a>
				<ul class="adminmenu">
					<li><a href="#"><i class="fa fa-file-o" aria-hidden="true"></i> 未発行のみ</a></li>
					<li><a href="#"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> 発行済のみ</a></li>
				</ul>
				</li>
				</ul>
		</nav>
		<nav class="headui">
			<ul>
				<li><?php echo htmlspecialchars($_SESSION['user_id'], ENT_QUOTES, 'UTF-8', true);?>
</li>
				<li><a href="#"><i class="fa fa-cog" aria-hidden="true"></i></a>
			<ul class="adminmenu">
				<li><a href="#" onclick="submit_c('branch-list');return false;"><i class="fa fa-building" aria-hidden="true"></i> 支店管理</a></li>
				<li><a href="#" onclick="submit_c('admin-list');return false;"><i class="fa fa-user" aria-hidden="true"></i> ユーザー管理</a></li>
				<li><a href="#" onclick="javascript:submit_c('holiday');return false;"><i class="fa fa-calendar-times-o" aria-hidden="true"></i> 祝日管理</a></li>
				<li><a href="#" onclick="javascript:submit_c('maintenance');return false;"><i class="fa fa-wrench" aria-hidden="true"></i> メンテナンス</a></li>
				<li><a href="#" onclick="javascript:submit_c('logout');return false;"><i class="fa fa-sign-out" aria-hidden="true"></i>ログアウト</a></li>
			</ul>
			</li>
				<li><a href="#" onclick="javascript:submit_c('password-edit');return false;"><i class="fa fa-user" aria-hidden="true"></i></a></li>
			</ul>
		</nav>
 </div>
 </header>

<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>