<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-02 14:40:23
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\TopPage.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16937584109478fcc49-06835406%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '175d2d4f02695894b1b1c314ee964cf8e3914ab5' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\TopPage.tpl',
      1 => 1480295785,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16937584109478fcc49-06835406',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_58410947973281_70528322',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58410947973281_70528322')) {function content_58410947973281_70528322($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<body>
<div class="form-box">
<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


  <form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
    <p>TOP画面</p>
    <p>Testing</p>

<table border=1>
 <tr>
 <th>チェック</th>
 <th>ステータス</th>
 <th>受付日</th>
 <th>契約番号</th>
 <th>お名前</th>
 <th>受付種別</th>
 <th>希望日</th>
 <th>操作</th>

</tr>
  <tr>
    <td>Test</td>
    <td>Test</td>
    <td>Test</td>
     <td>Test</td>
      <td>Test</td>
       <td>Test</td>
        <td>Test</td>
         <td>Test</td>
  </tr>
  <tr>
    <td>Test</td>
    <td>Test</td>
    <td>Test</td>
     <td>Test</td>
      <td>Test</td>
       <td>Test</td>
        <td>Test</td>
         <td>Test</td>
  </tr>
  <tr>
    <td>Test</td>
    <td>Test</td>
    <td>Test</td>
     <td>Test</td>
      <td>Test</td>
       <td>Test</td>
        <td>Test</td>
         <td>Test</td>
  </tr>

  <tr>
		 <td colspan="8">すべてチェック</td>
  </tr>

  <tr>

  	  <td colspan="8">
  	  <div>
  	   <a href="#" class="btn btn-primary" onclick="javascript:submit_c_Confirm('#', '#'); return false;"><i class="fa fa-refresh"></i> ー括単票出カ　
		</a>

  	   <a href="#" class="btn btn-danger" onclick="javascript:submit_a_delConfirm('delete'); return false;"><i class="fa fa-trash"></i> ー括削除
</a>

          </div>

      </td>
  </tr>
</table>



  </form>
  <br>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("PageEnd.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }} ?>