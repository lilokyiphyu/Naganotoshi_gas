<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-14 15:46:39
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\PasswordEdit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1676158410982c355d0-96552950%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6a9f1bfd2b6b931a053d6db1d9e6bae0b772697c' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\PasswordEdit.tpl',
      1 => 1481696967,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1676158410982c355d0-96552950',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_58410982d40328_29302743',
  'variables' => 
  array (
    'id' => 0,
    'user_id' => 0,
    'password' => 0,
    'now_password' => 0,
    'new_password' => 0,
    'confrim_password' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58410982d40328_29302743')) {function content_58410982d40328_29302743($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			<div class="wrapper">
				<h2>パスワード変更</h2>
					<div class="col12">
						<div class="block">
							<div class="form-group">
								<table cellspacing="0" class="vtable">
								<tbody>
										<input name="id" type="hidden" class="w460 imeoff"  value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['id']->value, ENT_QUOTES, 'UTF-8', true);?>
">
										<input name="user_id" type="hidden" class="w460 imeoff" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['user_id']->value, ENT_QUOTES, 'UTF-8', true);?>
">
										<input name="password" type="hidden" class="w460 imeoff"  value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['password']->value, ENT_QUOTES, 'UTF-8', true);?>
">
									<tr>
										<th scope="row"><span class="must">必須</span> 現在のパスワード</th>
										<td><input name="now_password" type="password" class="w460 imeoff" placeholder="現在のパスワード" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['now_password']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
									</tr>
									<tr>
										<th scope="row"><span class="must">必須</span> 新しいパスワード</th>
										<td><input name="new_password" type="password" class="w460 imeoff" placeholder="新しいパスワード" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['new_password']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
									</tr>
									<tr>
										<th scope="row"><span class="must">必須</span> 新しいパスワード<span class="mini">(確認)</span></th>
										<td><input name="confrim_password" type="password" class="w460 imeoff" placeholder="新しいパスワード（確認）" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['confrim_password']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
									</tr>
								</tbody>
								</table>
							</div>
						</div>
					</div>
					<nav class="submitbtnarea">
						<ul class="btnarea-left">
							<li>
								<button type="button"><i class="fa fa-chevron-left"></i> 戻る</button>
							</li>
						</ul>
						<ul>
							<li><a href="#" class="btn btn-next" onclick="javascript:submit_c_Confirm('password-edit', 'edit'); return false;" ><i class="fa fa-repeat" aria-hidden="true"></i> 更新</a></li>
						</ul>
					</nav>
			</div><!--wrapper-->
</form>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>