<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-13 13:12:18
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\AdminList.tpl" */ ?>
<?php /*%%SmartyHeaderCode:27465584103f974b9a9-35157541%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e9cfeba31248107ee161c8813e2f09208538c968' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\AdminList.tpl',
      1 => 1481596225,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '27465584103f974b9a9-35157541',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_584103f98541a9_05971715',
  'variables' => 
  array (
    'admin_list' => 0,
    'admin' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_584103f98541a9_05971715')) {function content_584103f98541a9_05971715($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('title'=>"管理アカウント一覧",'class'=>3), 0);?>

<form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			<div class="wrapper">
				<nav class="titlebtnarea">
					<ul class="btnarea-right">
						<li>
							<a href="admin-regist" class="btn btn-sm btn-submit" onclick="javascript:submit_c('admin-regist'); return false;"><i class="fa fa-plus" aria-hidden="true"></i>新規作成</a>
						</li>
					</ul>
				</nav>
					<h2>ユーザー一覧</h2>
				<div class="col12">
					<div class="block">
						<table cellspacing="0" class="htable">
							<thead>
								<tr>
									<th width="" scope="col">支店名</th>
									<th width="" scope="col">ユーザー名</th>
									<th width="" scope="col">メールアドレス</th>
									<th scope="col">&nbsp;</th>
								</tr>
							</thead>
							<tbody>
							<?php  $_smarty_tpl->tpl_vars['admin'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['admin']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['admin_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['admin']->key => $_smarty_tpl->tpl_vars['admin']->value){
$_smarty_tpl->tpl_vars['admin']->_loop = true;
?>
								<tr>
									<td class="branch_name"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['admin']->value['branch_name'], ENT_QUOTES, 'UTF-8', true);?>
</td>
									<td class="name"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['admin']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
</td>
									<td class="email"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['admin']->value['email'], ENT_QUOTES, 'UTF-8', true);?>
</td>
									<td class="btncel"><a href="" class="btn btn-sm btn-next" onclick="JavaScript:submit_c('admin-edit', 'index', 'id', <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['admin']->value['id'], ENT_QUOTES, 'UTF-8', true);?>
); return false;"><i class="fa fa-pencil" aria-hidden="true"></i> 編集</a></td>
								</tr>
							<?php } ?>
							</tbody>
						</table>
					</div>
			</div>
			<nav class="submitbtnarea">
				<ul class="btnarea-left">
					<li>
						<button type="button"><i class="fa fa-chevron-left" aria-hidden="true"></i> 戻る</button>
					</li>
				</ul>
			</nav>
		</div><!--form-->
</form>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>