<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-07 16:53:10
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\MaintenanceList.tpl" */ ?>
<?php /*%%SmartyHeaderCode:200125847bfe60de753-04882219%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '57cbb542f0a4314831dc46fbb62913f11f4e2e8e' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\MaintenanceList.tpl',
      1 => 1481096939,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '200125847bfe60de753-04882219',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_5847bfe6113b15_37873471',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5847bfe6113b15_37873471')) {function content_5847bfe6113b15_37873471($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
<div class="wrapper">
		<h2>メンテナンス</h2>
		<div class="col12">
			<div class="block">
				<div class="form-group">
					<table cellspacing="0" class="vtable">
						<tbody>
							<tr>
								<th scope="row">メッセージ</th>
								<td>
									<textarea name="name" rows="8" placeholder="メッセージ">メンテナンス中です</textarea>
									<span class="textlength"></span>
								</td>
							</tr>
							<tr>
								 <th scope="row">状態</th>
								 <td><input name="sex" type="radio" id="sexMale" value="sexMale" checked>
								 <label for="sexMale">稼働</label>
								 <input name="sex" type="radio" id="sexFemale" value="sexFemale">
								 <label for="sexFemale">停止</label></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<nav class="submitbtnarea">
			<ul class="btnarea-left">
				<li>
				<button type="button"><i class="fa fa-chevron-left" aria-hidden="true"></i> 戻る</button>
				</li>
			</ul>
			<ul>
				<li><a href="#" class="btn btn-next"><i class="fa fa-repeat" aria-hidden="true"></i> 更新</a></li>
			</ul>
		</nav>
</div>
</form>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<?php }} ?>