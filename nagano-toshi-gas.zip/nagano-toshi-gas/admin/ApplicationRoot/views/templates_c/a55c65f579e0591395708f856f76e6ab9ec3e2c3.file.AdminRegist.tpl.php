<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-13 14:18:37
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\AdminRegist.tpl" */ ?>
<?php /*%%SmartyHeaderCode:75235844bb4ca4b133-30743766%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a55c65f579e0591395708f856f76e6ab9ec3e2c3' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\AdminRegist.tpl',
      1 => 1481596649,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '75235844bb4ca4b133-30743766',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_5844bb4cafc514_14160399',
  'variables' => 
  array (
    'id' => 0,
    'branch_list' => 0,
    'branch' => 0,
    'select_name' => 0,
    'admin_list' => 0,
    'name' => 0,
    'email' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5844bb4cafc514_14160399')) {function content_5844bb4cafc514_14160399($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('title'=>"顧客新規登録",'class'=>6), 0);?>

<form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			<div class="wrapper">
				<h2>ユーザー新規登録</h2>
					<div class="col12">
						<div class="block">
							<div class="info-area">infoメッセージ</div>
								<div class="form-group">
									<table cellspacing="0" class="vtable">
										<tbody>
											<input type="hidden" id="id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['id']->value, ENT_QUOTES, 'UTF-8', true);?>
">
										<tr>
											<th scope="row"><span class="must">必須</span>支店</th>
											<td>
												<span class="select">
											<select name="branch_name" id="branch_name" class="w460">
												<?php  $_smarty_tpl->tpl_vars['branch'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['branch']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['branch_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['branch']->key => $_smarty_tpl->tpl_vars['branch']->value){
$_smarty_tpl->tpl_vars['branch']->_loop = true;
?>
												<option value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['branch']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
"<?php if ($_smarty_tpl->tpl_vars['branch']->value['name']==$_smarty_tpl->tpl_vars['select_name']->value){?>selected<?php }?>><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['branch']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
</option>
												<?php } ?>
											</select>
												</span>
											</td>
						 				</tr>
										<tr>
											<th scope="row">支店</th>
											<td><div class="readonly"> <?php if ($_smarty_tpl->tpl_vars['admin_list']->value['branch_name']=='0'){?>Head<?php }elseif($_smarty_tpl->tpl_vars['admin_list']->value['branch_name']=='1'){?>Branch<?php }?>東信支店 //支店管理者の場合</div><td>
										</tr>
										<tr>
											<th scope="row">ユーザー名</th>
											<td><input name="name" type="text" class="w460 imeoff" placeholder="ユーザー名" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['name']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
										</tr>
										<tr>
											<th scope="row"><span class="must">必須</span>メールアドレス</th>
											<td><input name="email" type="text" class="w460" placeholder="管理者メールアドレス" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['email']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
										</tr>
										</tbody>
									</table>
							</div>
						</div>
					</div>
					<nav class="submitbtnarea">
						<ul class="btnarea-left">
							<li>
								<button type="button"><i class="fa fa-chevron-left"></i> 戻る</button>
							</li>
						</ul>
						<ul>
							<li>
								<a href="#" class="btn btn-submit" onclick="javascript:submit_a_Confirm('regist'); return false;"><i class="fa fa-check" aria-hidden="true"></i> 登録</a>
							</li>
						</ul>
					</nav>
					<p class="endnote">登録するとパスワードがメールアドレスに送信されます。</p>
			</div><!--wrapper-->
</from>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }} ?>