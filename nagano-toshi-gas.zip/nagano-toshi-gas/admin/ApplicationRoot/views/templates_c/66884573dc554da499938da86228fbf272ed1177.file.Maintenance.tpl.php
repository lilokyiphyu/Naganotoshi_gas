<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-12 17:04:34
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\Maintenance.tpl" */ ?>
<?php /*%%SmartyHeaderCode:31458584dfcdf9cfcd2-11344652%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '66884573dc554da499938da86228fbf272ed1177' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\Maintenance.tpl',
      1 => 1481529035,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '31458584dfcdf9cfcd2-11344652',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_584dfcdfa0d596_27710839',
  'variables' => 
  array (
    'id' => 0,
    'message' => 0,
    'maintenance_list' => 0,
    'maintenance' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_584dfcdfa0d596_27710839')) {function content_584dfcdfa0d596_27710839($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
<div class="wrapper">
		<h2>メンテナンス</h2>
		<div class="col12">
			<div class="block">
				<div class="form-group">
					<table cellspacing="0" class="vtable">
						<tbody>
							<tr>
								<input class="input-large" type="hidden" name="id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['id']->value, ENT_QUOTES, 'UTF-8', true);?>
"></label>
								<th scope="row">メッセージ</th>
								<td>
									 <textarea name="message" rows="8" placeholder="メッセージ"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['message']->value, ENT_QUOTES, 'UTF-8', true);?>
</textarea>
									<span class="textlength"></span>
								</td>
							</tr>
							<tr>
								<th scope="row">状態</th>
								 <td>
									<input name="status" type="radio" id="operation" value="operation" <?php if ($_smarty_tpl->tpl_vars['maintenance_list']->value['status']==$_smarty_tpl->tpl_vars['maintenance']->value['operation']){?>checked<?php }?>>
									<label for="operation">稼働</label>
									<input name="status" type="radio" id="stop" value="stop" <?php if ($_smarty_tpl->tpl_vars['maintenance_list']->value['status']==$_smarty_tpl->tpl_vars['maintenance']->value['stop']){?>checked<?php }?>>
									<label for="stop">停止</label>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<nav class="submitbtnarea">
			<ul class="btnarea-left">
				<li>
				<button type="button"><i class="fa fa-chevron-left" aria-hidden="true"></i> 戻る</button>
				</li>
			</ul>
			<ul>
				<li><a href="#" class="btn btn-next" onclick="javascript:submit_a_Confirm('edit'); return false;"><i class="fa fa-repeat" aria-hidden="true"></i> 更新</a></li>
			</ul>
		</nav>
</div>
</form>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<?php }} ?>