<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-13 15:18:02
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\Holiday.tpl" */ ?>
<?php /*%%SmartyHeaderCode:65325848e456c4f885-75299910%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c88c769a1bad646d6c0060b1240e5a6e2cc1af34' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\Holiday.tpl',
      1 => 1481597590,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '65325848e456c4f885-75299910',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_5848e456c96cb5_00829559',
  'variables' => 
  array (
    'holiday_arr' => 0,
    'holiday' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5848e456c96cb5_00829559')) {function content_5848e456c96cb5_00829559($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data" class="form-horizontal">
<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			<div class="wrapper">
				<h2>祝日設定</h2>
					<div class="col12">
						<div class="block">
							<div class="form-group">
								<table cellspacing="0" class="vtable">
									<tbody>
										<tr>
											<th scope="row">祝日</th>
											<td><textarea name="holiday_name" rows="8" placeholder="祝日" data-max="2000" data-min="1"><?php  $_smarty_tpl->tpl_vars["holiday"] = new Smarty_Variable; $_smarty_tpl->tpl_vars["holiday"]->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['holiday_arr']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars["holiday"]->key => $_smarty_tpl->tpl_vars["holiday"]->value){
$_smarty_tpl->tpl_vars["holiday"]->_loop = true;
?><?php echo htmlspecialchars(preg_replace('!\s+!u', ' ',$_smarty_tpl->tpl_vars['holiday']->value), ENT_QUOTES, 'UTF-8', true);?>

<?php } ?></textarea>
												<span class="textlength"></span>
												<p class="asterisk">2017/01/01の形式で一行づつ入力してください。</p>
											</td>
										</tr>
					 				</tbody>
								</table>
							</div>
						</div>
					</div>
					<nav class="submitbtnarea">
							<ul class="btnarea-left">
								<li>
									<button type="button" ><i class="fa fa-chevron-left" aria-hidden="true"></i> 戻る</button>
								</li>
							</ul>
							<ul>
								<li>
									<a href="#" class="btn btn-next" onclick="submit_c_Confirm('holiday', 'edit'); return false;"><i class="fa fa-repeat" aria-hidden="true"></i> 更新</a>
								</li>
							</ul>
					</nav>
			</div><!--wrapper-->
</form>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>