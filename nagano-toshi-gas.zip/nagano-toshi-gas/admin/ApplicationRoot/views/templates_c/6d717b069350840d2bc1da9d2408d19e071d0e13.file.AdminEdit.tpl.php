<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-13 15:33:38
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\AdminEdit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9832584103fde19135-20343571%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6d717b069350840d2bc1da9d2408d19e071d0e13' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\AdminEdit.tpl',
      1 => 1481595892,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9832584103fde19135-20343571',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_584103fdf129e4_69946801',
  'variables' => 
  array (
    'id' => 0,
    'user_id' => 0,
    'branch_list' => 0,
    'branch' => 0,
    'select_name' => 0,
    'admin_list' => 0,
    'name' => 0,
    'email' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_584103fdf129e4_69946801')) {function content_584103fdf129e4_69946801($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("PageHeader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<form name="mainform" id="mainform" method="post" action="" enctype="multipart/form-data">
<?php echo $_smarty_tpl->getSubTemplate ("Message.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			<div class="wrapper">
			<h2>支店編集</h2>
				<div class="col12">
					<div class="block">
						<div class="error-area">errorメッセージ</div>
							<div class="form-group">
								<table cellspacing="0" class="vtable">
									<tbody>
										<label><input class="input-large" type="hidden" name="id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['id']->value, ENT_QUOTES, 'UTF-8', true);?>
"></label>
										<label><input class="input-large" type="hidden" name="user_id" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['user_id']->value, ENT_QUOTES, 'UTF-8', true);?>
"></label>
									<tr>
										<th scope="row"><span class="must">必須</span>支店</th>
										<td>
											<span class="select">
												<select name="branch_name" id="branch_name" class="w460">
													<?php  $_smarty_tpl->tpl_vars['branch'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['branch']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['branch_list']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['branch']->key => $_smarty_tpl->tpl_vars['branch']->value){
$_smarty_tpl->tpl_vars['branch']->_loop = true;
?>
													<option value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['branch']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
" <?php if ($_smarty_tpl->tpl_vars['branch']->value['name']==$_smarty_tpl->tpl_vars['select_name']->value){?>selected<?php }?>><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['branch']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
</option>
													<?php } ?>
												</select>
											</span>
										</td>
						 			</tr>
									<tr>
										<th scope="row">支店</th>
										<td><div class="readonly"><?php if ($_smarty_tpl->tpl_vars['admin_list']->value['branch_name']=='0'){?>Head<?php }elseif($_smarty_tpl->tpl_vars['admin_list']->value['branch_name']=='1'){?>Branch<?php }?>東信支店 //支店管理者の場合</div></td>
									</tr>
									<tr>
										<th scope="row">ユーザー名</th>
										<td><input name="name" type="text" class="w460 imeoff" placeholder="ユーザー名" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['name']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
									</tr>
									<tr>
										<th scope="row"><span class="must">必須</span>メールアドレス</th>
										<td><input name="email" type="text" class="w460" placeholder="管理者メールアドレス" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['email']->value, ENT_QUOTES, 'UTF-8', true);?>
"></td>
 									</tr>
									</tbody>
								</table>
						</div>
					</div>
				</div>
				<nav class="submitbtnarea">
					<ul class="btnarea-left">
						<li>
							<button type="button"><i class="fa fa-chevron-left"></i> 戻る</button>
						</li>
					</ul>
					<ul>
						<li><a href="#" class="btn btn-next" onclick="submit_c_Confirm('admin-edit', 'edit'); return false;"><i class="fa fa-repeat" aria-hidden="true"></i> 更新</a></li>
						<li><a href="#" class="btn btn-default" onclick="javascript:submit_c('password-edit'); return false;"><i class="fa fa-paper-plane" aria-hidden="true"></i> パスワードリセット</a></li>
						<li><a href="#" class="btn btn-del" onclick="submit_a_delConfirm('delete'); return false;"><i class="fa fa-trash" aria-hidden="true"></i> 削除</a></li>
					</ul>
				</nav>
				<p class="endnote">パスワードリセットを行うと、初期パスワードがメールアドレスに送信されます。</p>
			</div><!--wrapper-->
</form>
<?php echo $_smarty_tpl->getSubTemplate ("PageFooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<?php }} ?>