<?php /* Smarty version Smarty-3.1-DEV, created on 2016-12-12 18:03:11
         compiled from "C:\www2\nagano-toshi-gas\admin\ApplicationRoot\views\templates\PageFooter.tpl" */ ?>
<?php /*%%SmartyHeaderCode:29445584103fa832d37-23630935%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fe31af2faacc39067e493d0357fd613002739eaf' => 
    array (
      0 => 'C:\\www2\\nagano-toshi-gas\\admin\\ApplicationRoot\\views\\templates\\PageFooter.tpl',
      1 => 1481533252,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '29445584103fa832d37-23630935',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_584103fa8744d5_22224841',
  'variables' => 
  array (
    'doc_root' => 0,
    'site_name' => 0,
    'controller_name' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_584103fa8744d5_22224841')) {function content_584103fa8744d5_22224841($_smarty_tpl) {?><footer>&copy; Copyright 2017 Nagano toshi Gas. All Rights Reserved.</footer>
</section>
</aside>
</div>
<script src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['doc_root']->value, ENT_QUOTES, 'UTF-8', true);?>
js/app.js" type="text/javascript"></script>
<script type="text/javascript">
	var g_site_name = '<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['site_name']->value, ENT_QUOTES, 'UTF-8', true);?>
';
	var g_controllerName = '<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['controller_name']->value, ENT_QUOTES, 'UTF-8', true);?>
';
</script>
<div id="waitlay"></div>
<script src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['doc_root']->value, ENT_QUOTES, 'UTF-8', true);?>
js/jquery-3.1.0.min.js"></script>
<script src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['doc_root']->value, ENT_QUOTES, 'UTF-8', true);?>
js/jquery.dataTables.min.js"></script>
<script src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['doc_root']->value, ENT_QUOTES, 'UTF-8', true);?>
js/dataTables.select.min.js"></script>
<script src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['doc_root']->value, ENT_QUOTES, 'UTF-8', true);?>
js/dataTables.buttons.min.js"></script>
<script src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['doc_root']->value, ENT_QUOTES, 'UTF-8', true);?>
js/common.js"></script>

</body>
</html>

<?php }} ?>