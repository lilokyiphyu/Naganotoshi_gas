<?php

require_once 'framework/ControllerAbstract.php';
require_once 'helper/SessionManager.php';
require_once 'Exception.php';
require_once 'helper/HtmlTagData.php';


class AdminEditController extends Framework_ControllerAbstract
{
	protected function _getValidationSetting() {
		return array('edit' => array('validation_user.ini', 'regist'));
	}
	public function indexAction()
	{
		$this->_setupView();
		$this->_render('AdminEdit');
	}

	private function _setupView()
	{
		$user_info			= SessionManager::getUserInfo();
		$id					= $this->_getParam('id');
		$param				= array();
		$branch_list = Functions::selectFrom($this->_getDBh(), 't_branch', $param);

		$this->_smarty->assign('branch_list', $branch_list);
		$this->_smarty->assign('id', $branch_list[0]["id"]);
		$this->_smarty->assign('select_name', $this->_getParam('branch_name')); //assign the select name

		$id					=  $this->_getParam('id');
		$user_id			=  $this->_getParam('user_id');
		$name				=  $this->_getParam('name');
		$email				=  $this->_getParam('email');

		$param = array(
				 "id"=>$id
		);
		$admin_list = Functions::selectFrom($this->_getDBh(), 't_admin_user', $param);
		$this->_smarty->assign('admin_list', $admin_list);
		$this->_smarty->assign('id', $admin_list[0]["id"]);
		$this->_smarty->assign('user_id', $admin_list[0]["user_id"]);
		$this->_smarty->assign('name', $admin_list[0]["name"]);
		$this->_smarty->assign('email', $admin_list[0]["email"]);
	}

	//sample update action
	public function editAction()
	{
		$user_info 	= SessionManager::getUserInfo();
		$id					=  $this->_getParam('id');
		$user_id			=  $this->_getParam('user_id');
		$branch_name		=  $this->_getParam('branch_name');
		$name				=  $this->_getParam('name');
		$email				=  $this->_getParam('email');

		$param = array(

				"branch_name"		=>$branch_name
				,"name"				=>$name
				,"email"			=>$email
		);

		$where = array(
				 "id"=>$id
		);

		if ($name != 0) {
			$err_msg[] = ErrMessage::create('1', 'error', "check", '', '');
			$this->_smarty->assign('err_msg', $err_msg);
			$this->_setupView();
			$this->_rerender();
			return;
		}

		if (!filter_var($email, FILTER_VALIDATE_EMAIL))
		{
			$err_msg[] = ErrMessage::create('1', 'error', "メールをチェックする", '', '');
			$this->_smarty->assign('err_msg', $err_msg);
			$this->_setupView();
			$this->_rerender();
			return;
		}//Email format checking error

		$ret = Functions::updateTo($this->_getDBh(), 't_admin_user', $param,$where,'0');
		$this->_setupView();
		$this->_forward('index', 'admin-list');
	}

	public function deleteAction()
	{
		$user_info 	= SessionManager::getUserInfo();
		$id					=  $this->_getParam('id');
		$branch_name		=  $this->_getParam('branch_name');
		$name				=  $this->_getParam('name');
		$email				=  $this->_getParam('email');
		// 更新処理
		$param = array(
				"branch_name"		=>$branch_name
				,"name"				=>$name
				,"email"			=>$email

		);
		$where = array(
				 "id"=>$id
		);
		$ret = Functions::deleteFrom($this->_getDBh(), 't_admin_user', $param,$where,'0');
		$this->_forward('index', 'admin-list');
	}
}