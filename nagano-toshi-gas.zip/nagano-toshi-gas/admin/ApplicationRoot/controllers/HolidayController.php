<?php

require_once 'framework/ControllerAbstract.php';
require_once 'helper/SessionManager.php';
require_once 'Exception.php';
require_once 'helper/HtmlTagData.php';


class HolidayController extends Framework_ControllerAbstract
{
	private $session = NULL;
	protected function _getValidationSetting() {
		//return array('edit' => array('validation_password.ini', 'edit'));
	}

	public function indexAction()
	{
		$file = AppConfig::get('holiday_txt_path');
		$fp = fopen($file, "r");
		$holiday_str = fread($fp, filesize($file));
		fclose($fp);
		$holiday_arr	= explode("\r\n", $holiday_str);
		$this->_smarty->assign('holiday_arr', $holiday_arr);
		$this->_setupView();
		$this->_render('Holiday');
	}

	private function _setupView()
	{
		$user_info = SessionManager::getUserInfo();
	}

	public function editAction()
	{
		$holiday_name	= $this->_getParam('holiday_name');
		$holiday		= fopen(AppConfig::get('holiday_txt_path'),"w") ;
		$holiday		= fopen(AppConfig::get('holiday_txt_path'),"a") ;
		$holiday_arr	= explode("\n\r", $holiday_name);

		foreach($holiday_arr as $holiday_name)
		{
			$ymd_arr = explode("/", $holiday_name);
			if(!checkdate($ymd_arr[1] , $ymd_arr[2] , $ymd_arr[0])){
			$err_msg[] = ErrMessage::create('1', 'error', "yyy/mm/d チェック", '', '');
			$this->_smarty->assign('err_msg', $err_msg);
			$this->_setupView();
			$this->_rerender();
			return;
			}
		}
		$new_data = "\n\r".$holiday_name;
		fwrite($holiday, $new_data);
		fclose($holiday);
		$this->_forward('index');
	}
}