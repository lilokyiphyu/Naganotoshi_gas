<?php
require_once 'Pdf.php';
require_once 'TplFile.php';

class PdfHelper extends Pdf {
	private $_tplFile;
	private $_savedir;
	private $_filename;
	private $_viewFooter;
	private $_imagepath;
	private $_imagex;
	private $_imagey;

	public function __construct($savedir, $filename, $tpl, $dir=NULL, $viewFooter=false, $imagepath, $imagex=0, $imagey=0, $options) {
		parent::__construct($options);
		$this->_tplFile = new TplFile($tpl.'.tpl', $dir);
		$this->_savedir = $savedir;
		$this->_filename = $filename;
		$this->_viewFooter = $viewFooter;
		$this->_imagepath = $imagepath;
		$this->_imagex = $imagex;
		$this->_imagey = $imagey;
	}

	public function assign($key, $val=NULL) {
		$this->_tplFile->assign($key, $val);
	}

	public function createPdf() {
		$this->_tplFile->createAsStr();
		$this->getPdfFile($this->_savedir, $this->_filename, $this->_tplFile->getfilestr(), $this->_viewFooter, $this->_imagepath, $this->_imagex, $this->_imagey);

	}
}
?>
