<?php

require_once "AppConfig.php";
require_once "framework/SessionManagerAbstract.php";
require_once 'HtmlTagData.php';

session_cache_limiter('none');

class SessionManager extends Framework_SessionManagerAbstract
{

	public static function isNotLogin() {
		@session_start();
		return (empty($_SESSION['sesid'])
			|| $_SESSION['sesid'] == ''
			|| $_SESSION['site_id'] != AppConfig::get('site_id')
		);
	}

	public static function login($user) {
		$session_id						= parent::startSession();
		$_SESSION['sesid']				= $session_id;
		$_SESSION['b.id']				= $user['branch_id'];
		$_SESSION['b.name']				= $user['branch_name'];
		$_SESSION['b.branch_number1']   = $user['branch_number1'];
		$_SESSION['b.branch_number2']   = $user['branch_number2'];
		$_SESSION['id']					= $user['id'];
		$_SESSION['user_id']			= $user['user_id'];
		$_SESSION['password']			= $user['password'];
		$_SESSION['name']				= $user['name'];
		$_SESSION['branch_name']				= $user['branch_name'];
		$_SESSION['auth']				= $user['auth'];
		$_SESSION['AUTHORITY_NAME']		= HtmlTagData::$SelectBoxUserAuthority[$user['AUTHORITY']];// password
		$_SESSION['site_id']			= AppConfig::get('site_id');	// サイトID
		Logger::getRootLogger()->debug('LOGIN with session_id :'.$session_id);
	}




	public static function logout() {
		parent::destroySession();
		Logger::getRootLogger()->debug('LOGOUT');
	}

	public static function getUserInfo() {
		return array(
			'sesid'    			=> $_SESSION['sesid'],
			'b.id'				=> $_SESSION['b.id'],
			'b.name'			=> $_SESSION['b.branch_name'],
			'b.branch_number1' 	=> $_SESSION['b.branch_number1'],
			'b.branch_number2' 	=> $_SESSION['b.branch_number2'],
			'id'				=> $_SESSION['id'],
			'user_id'			=> $_SESSION['user_id'],
			'password'			=> $_SESSION['password'],
			'name'				=> $_SESSION['name'],
			'branch_name'		=> $_SESSION['branch_name'],
			'auth'				=> $_SESSION['auth'],
			'site_id'			=> $_SESSION['site_id']
		);
	}






	public static function role($role) {
		if (SessionManager::isNotLogin())
			throw new Exception('Save-method failure. Session is available only after login!');

		$arr = array();
		foreach($role as $val){
			$arr[$val['role_code']] = $val['role_id'];
		}
		$_SESSION['role'] = $arr;
		var_dump($arr);
	}

	public static function saveCondition($controller, $param) {
		if (SessionManager::isNotLogin())
			throw new Exception('Save-method failure. Session is available only after login!');
		parent::saveCondition($controller, $param);
	}

	public static function saveDispdata($controller, $param) {
		if (SessionManager::isNotLogin())
			throw new Exception('Save-method failure. Session is available only after login!');
		parent::saveDispdata($controller, $param);
	}

	public static function saveTransitionParam($param) {
		if (SessionManager::isNotLogin())
			throw new Exception('Save-method failure. Session is available only after login!');
		parent::saveTransitionParam($param);
	}

	public static function saveBookId($param) {
		if (SessionManager::isNotLogin())
			throw new Exception('Save-method failure. Session is available only after login!');
		$_SESSION['book_id'] = $param;
	}
	public static function getBookId() {
		if (SessionManager::isNotLogin())
			throw new Exception('Save-method failure. Session is available only after login!');
		if (!isset($_SESSION['book_id']))
			throw new Exception('Not Selected Book! Call after select book.');
		return $_SESSION['book_id'];
	}

	public static function saveMenuInfo($param) {
		if (SessionManager::isNotLogin())
			throw new Exception('Save-method failure. Session is available only after login!');
		$_SESSION['menu_info'] = $param;
	}
	public static function getMenuInfo() {
//		$_SESSION['menu_info']['menu_no']="010019";
//		$_SESSION['menu_info']['menu_type']=Definition::BOOK_TYPE_STAY;
//		$_SESSION['menu_info']['area_large_id']="00001";
//		$_SESSION['menu_info']['area_mid_id']="01001";
//		$_SESSION['menu_info']['area_small_id']="00006";
//		$_SESSION['menu_info']['category_large_id']=1;
//		$_SESSION['menu_info']['category_mid_id']=1;
//		$_SESSION['menu_info']['category_small_id']=1;


		if (SessionManager::isNotLogin())
			throw new Exception('Save-method failure. Session is available only after login!');
		if (!isset($_SESSION['menu_info']['menu_no']))
			throw new Exception('Not Selected Menu! Call after select menu.');

		// TODO:暫定的なもの。とりあえず宿泊orサービスの区別をつけたい

		//return $_SESSION['menu_info'];
		return array(
				"menu_no" => $_SESSION['menu_info']['menu_no'],
				"menu_type" => $_SESSION['menu_info']['menu_type'],
				"area_large_id" => $_SESSION['menu_info']['area_large_id'],
				"area_mid_id" => $_SESSION['menu_info']['area_mid_id'],
				"area_small_id" => $_SESSION['menu_info']['area_small_id'],
				"category_large_id" => $_SESSION['menu_info']['category_large_id'],
				"category_mid_id" => $_SESSION['menu_info']['category_mid_id'],
				"category_small_id" => $_SESSION['menu_info']['category_small_id'],
		);
	}

	public static function readySubmit() {
		if (SessionManager::isNotLogin())
			throw new Exception('startTranslate failure. Session is available only after login!');

		$_SESSION['ticket'] = md5(uniqid(rand(), true));
		return $_SESSION['ticket'];
	}

	public static function passSubmit() {
		if (SessionManager::isNotLogin())
			throw new Exception('submitTranslate failure. Session is available only after login!');

		$saved_ticket = isset($_SESSION['ticket']) ? $_SESSION['ticket'] : "";
		$post_ticket = isset($_POST['ticket']) ? $_POST['ticket'] : "";
		unset($_SESSION['ticket']);

		if(empty($post_ticket)){
			return false;
		}

		if($saved_ticket == $post_ticket){
			return true;
		}
		else{
			return false;
		}
	}

	public static function setSession($key, $val) {
//		if (SessionManager::isNotLogin())
//			throw new Exception('Save-method failure. Session is available only after login!');
		$_SESSION[$key] = $val;
	}
	public static function getSession($key) {
//		if (SessionManager::isNotLogin())
//			throw new Exception('Save-method failure. Session is available only after login!');
		return $_SESSION[$key];
	}
	public static function setCookie($key, $val, $expire) {
		if (SessionManager::isNotLogin())
			throw new Exception('Save-method failure. Session is available only after login!');
		$ret = setcookie($key, $val, $expire, '/');
	}
	public static function getCookie($key) {
		if (SessionManager::isNotLogin())
			throw new Exception('Save-method failure. Session is available only after login!');
		return $_COOKIE[$key];
	}

}