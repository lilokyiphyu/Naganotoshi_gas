<?php
require_once 'framework/ControllerAbstract.php';

class AutoLogin extends Framework_ControllerAbstract
{
	public function setup($user_id, $table_name, $cookie_name)
	{
		$auto_login_key = sha1(uniqid().mt_rand(1,999999999)); // keyを生成

		$set = array(
				'user_id' => $user_id,
				'cookie_key' => $auto_login_key,
		);
		$result = Functions::insertTo($this->_getDBh(), $table_name, $set, '0');

		setcookie($cookie_name, $auto_login_key, time()+3600*24*7, '/'); //有効期限7日の自動ログインクッキーを送信
	}

	public function logout($table_name, $cookie_name)
	{
		$key = $_COOKIE[$cookie_name];
		if (!empty($_COOKIE[$cookie_name])) {
			// 自動ログイン用のクッキーを削除
			setcookie($cookie_name, '', time() - 3600);
			// 自動ログインkeyを削除
			$where = array(
					'cookie_key' => $key,
			);
			Functions::deleteFrom($this->_getDBh(), $table_name, $where, 0, false);
		}
	}

	public function login($table_name, $cookie_name)
	{
		$key = $_COOKIE[$cookie_name];
		if(!empty($key)) {
			$where = array(
					'cookie_key' => $key,
			);
			$rec = Functions::selectFrom($this->_getDBh(), $table_name, $where);

			if(count($rec) > 0){
				// 古い自動ログインkeyを削除
				Functions::deleteFrom($this->_getDBh(), $table_name, $where, 0, false);
				AutoLogin::setup($rec[0]['user_id'], $table_name, $cookie_name);

				// 認証OK
				return $rec[0]['user_id'];
			}
			else{
				return false;
			}
		}
		return false;
	}
}