<?php

//require_once 'Zend/Controller/Action.php';
//require_once 'Exception.php';
require_once 'framework/ErrorController.php';


class ErrorController extends Framework_ErrorController
{

}
