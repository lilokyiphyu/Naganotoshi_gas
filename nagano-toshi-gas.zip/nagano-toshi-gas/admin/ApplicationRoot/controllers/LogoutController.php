<?php


require_once 'framework/ControllerAbstract.php';
require_once 'helper/SessionManager.php';
require_once 'helper/AutoLogin.php';


class LogoutController extends Framework_ControllerAbstract
{

	public function indexAction()
	{
		//AutoLogin::logout('t_auto_login', 'sch_auto_login');
		SessionManager::logout();
		$logger = $this->_getLogger();
		$logger->debug("logout");
		// show LoginPage
		 $this->_render('Login');
	}

}