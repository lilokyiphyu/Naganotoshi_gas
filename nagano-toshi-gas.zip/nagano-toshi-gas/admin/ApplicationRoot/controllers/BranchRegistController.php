<?php

require_once 'framework/ControllerAbstract.php';
require_once 'helper/SessionManager.php';
require_once 'Exception.php';
require_once 'helper/HtmlTagData.php';


class BranchRegistController extends Framework_ControllerAbstract
{
	private $session = NULL;
	protected function _getValidationSetting() {
		return array('regist' => array('validation_branch.ini', 'regist'));
	}

	public function indexAction()
	{
		$this->_setupView();
		$this->_render('BranchRegist');
	}

	private function _setupView()
	{
		$user_info			= SessionManager::getUserInfo();
		$id					= $this->_getParam('id');
		$name				= $this->_getParam('name');
		$branch_number1		= $this->_getParam('branch_number1');
		$branch_number2     = $this->_getParam('branch_number2');
		$admin_name			= $this->_getParam('admin_name');
		$email				= $this->_getParam('email');
		$this->_smarty->assign('name',$name);
		$this->_smarty->assign('branch_number1', $branch_number1);
		$this->_smarty->assign('branch_number2', $branch_number2);
		$this->_smarty->assign('admin_name', $admin_name);
		$this->_smarty->assign('email',   $email);
	}

	public function registAction()
	{
		$name				= $this->_getParam('name');
		$branch_number1     = $this->_getParam('branch_number1');
		$branch_number2     = $this->_getParam('branch_number2');
		$admin_name			= $this->_getParam('admin_name');
		$email				= $this->_getParam('email');

		// 登録処理
		$param = array(
				"name"				=>$name			//		//
				,"branch_number1"	=>$branch_number1
				,"branch_number2"	=>$branch_number2
				,"admin_name"	 	=>$admin_name
				,"email"	 		=>$email

		);
		$result = Functions::insertTo($this->_getDBh(),'t_branch',$param,'0');
		$this->_setupView();
		$this->_forward('index', 'branch-list');

	}
}
