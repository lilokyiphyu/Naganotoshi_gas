<?php

require_once 'framework/ControllerAbstract.php';
require_once 'helper/SessionManager.php';
require_once 'Exception.php';
require_once 'helper/HtmlTagData.php';


class MaintenanceController extends Framework_ControllerAbstract
{
	protected function _getValidationSetting() {
		return array('edit' => array('validation_user.ini', 'user'));
	}

	public function indexAction()
	{
		$this->_setupView();
		$this->_render('Maintenance');
	}

	private function _setupView()
	{
		$user_info				= SessionManager::getUserInfo();
		$id						= $this->_getParam('id');
		$message				= $this->_getParam('message');
		$status					= $this->_getParam('status');
		$param	=array();
		$maintenance_list = Functions::selectFrom($this->_getDBh(), 't_maintenance', $param);
		$this->_smarty->assign('maintenance_list', $maintenance_list);
		$this->_smarty->assign('id', $maintenance_list[0]["id"]);
		$this->_smarty->assign('message', $maintenance_list[0]["message"]);
		$this->_smarty->assign('status', $maintenance_list[0]["status"]);
	}

	public function editAction()

	{
		$id						= $this->_getParam('id');
		$message				= $this->_getParam('message');
		$status					= $this->_getParam('status');
		$param = array(
				"message"=>$message
				,"status"=>$status
		);
		$where = array(

				"id"=>$id
		);
		$maintenance_list = Functions::selectFrom($this->_getDBh(), 't_maintenance', $param);
		if(count($maintenance_list) == 0)
		{
			$result = Functions::insertTo($this->_getDBh(),'t_maintenance',$param);
		}
		else
		{
			$ret = Functions::updateTo($this->_getDBh(),'t_maintenance',$param,$where,0);
		}
		$this->_setupView();
		$this->_forward('index');
	}

}