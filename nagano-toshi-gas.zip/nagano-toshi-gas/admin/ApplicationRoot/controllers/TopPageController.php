<?php
require_once 'framework/ControllerAbstract.php';
require_once 'helper/SessionManager.php';
require_once 'helper/AutoLogin.php';
require_once 'Exception.php';

class TopPageController extends Framework_ControllerAbstract
{
	protected function _getValidationSetting() {

	}

		public function indexAction()
		{
			$this->_render('TopPage');
		}

}