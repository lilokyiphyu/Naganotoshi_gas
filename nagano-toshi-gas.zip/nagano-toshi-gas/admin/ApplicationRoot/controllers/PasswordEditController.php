<?php

require_once 'framework/ControllerAbstract.php';
require_once 'helper/SessionManager.php';
require_once 'Exception.php';
require_once 'helper/HtmlTagData.php';


class PasswordEditController extends Framework_ControllerAbstract
{
	protected function _getValidationSetting() {
	return array('edit' => array('validation_password.ini', 'edit'));
	}
	public function indexAction()
	{
		$this->_setupView();
		$this->_render('PasswordEdit');
	}
	private function _setupView() {
		$user_info = SessionManager::getUserInfo();
	}
	public function editAction()
	{
		$user_info			= SessionManager::getUserInfo();
		$now_password		= $this->_getParam('now_password');
		$new_password		= $this->_getParam('new_password');
		$confrim_password	= $this->_getParam('confrim_password');

		$id					= $user_info['id'];
		$user_id			= $user_info['user_id'];
		$password			= $user_info['password'];

		$param = array(
					"user_id"		=> $user_id
					,"password"		=> $password
		);

		$admin_list = Functions::selectFrom($this->_getDBh(), t_admin_user, $param);
		$this->_smarty->assign('id', $branch_list[0]["id"]);
		$this->_smarty->assign('user_id', $branch_list[0]["user_id"]);
		$this->_smarty->assign('password', $branch_list[0]["password"]);

		if(trim ($now_password) == "" || trim ($password) == "" || trim ($confrim_password) == "") {
		$err_msg[] = ErrMessage::create('1', 'error', "show error。", '', '');
		$this->_smarty->assign('err_msg', $err_msg);
		$this->_setupView(null,null);
		$this->_rerender();
		return;
	}

	if($now_password != $admin_list[0]["password"]){
		$err_msg[] = ErrMessage::create('1', 'error', "現在のパスワードが違います。", '', '');
		$this->_smarty->assign('err_msg', $err_msg);
		$this->_setupView();
		$this->_rerender();
		return;
	}

	if($new_password != $confrim_password){
		$err_msg[] = ErrMessage::create('1', 'error', "パスワード確認が違います。", '', '');
		$this->_smarty->assign('err_msg', $err_msg);
		$this->_setupView();
		$this->_rerender();
		return;
	}
	// 更新処理
		$param = array(
				"password"=>$new_password
		);
		$where = array("id"=>$id);
		$ret = Functions::updateTo($this->_getDBh(), 't_admin_user', $param,$where,'0');
		$this->_forward('index','password-edit');
		$this->_setupView();
		$this->_rerender();

	}

}
