<?php

require_once 'framework/ControllerAbstract.php';
require_once 'helper/SessionManager.php';
require_once 'helper/AutoLogin.php';
require_once 'Exception.php';


class LoginController extends Framework_ControllerAbstract
{
	protected function _getValidationSetting() {
		return array('login' => array('validation_user.ini', 'login'));
	}

	public function indexAction()
	{
		@SessionManager::logout(); // 未セッション時のWarning抑止
		$this->_render('Login');
	}

	public function loginAction()
	{
		// ログイン
		$user_id = $this->_getParam('user_id');
		$password = $this->_getParam('password');
		$ret = $this->_query(NULL, "select_login", array($user_id, $password));
		if (count($ret) == 0) {
		$err_msg[] = ErrMessage::create('1', 'ログイン', '', Message::MSG_LOGIN_NG, '', '', '',  '');
		$this->_smarty->assign('err_msg', $err_msg);
		$this->_rerender();
		return;
	}
		$this->_getLogger()->debug("lets login check!");
		SessionManager::login($ret[0]);
		$this->_getLogger()->debug("Login success. - {$userid}:{$password}");
		$this->_forward('index', 'top-page'); // redirect
	}
}