<?php

require_once 'framework/ControllerAbstract.php';
require_once 'helper/SessionManager.php';
require_once 'Exception.php';
require_once 'helper/HtmlTagData.php';
require_once 'Zend/Validate.php';


class AdminListController extends Framework_ControllerAbstract
{
	private $session = NULL;
	protected function _getValidationSetting() {
		return array();
	}
	public function indexAction()
	{
		$this->_setupView();
		$this->_render('AdminList');
	}
	private function _setupView()
	{
		$user_info		= SessionManager::getUserInfo();
		$param			= $this->_getParams();
		$param			= array();

		// 全件を取得
		$admin_list		= Functions::selectFrom($this->_getDBh(), 't_admin_user', $param);

		// Session Dispdata に格納用
		$lists	= array('disp_list'     => $admin_list,
						'param'         => $param,
						'search_assign' => '');

		// Session Dispdataへ格納
		$this->_saveDispdata($lists);
		$this->_smarty->assign('admin_list', $admin_list);
	}
}



