<?php

require_once 'framework/ControllerAbstract.php';
require_once 'helper/SessionManager.php';
require_once 'Exception.php';
require_once 'helper/HtmlTagData.php';


class BranchEditController extends Framework_ControllerAbstract
{
	protected function _getValidationSetting() {
		return array('edit' => array('validation_branch.ini', 'regist'));
	}

	public function indexAction()
	{
		$this->_setupView();
		$this->_render('BranchEdit');
	}

	private function _setupView()
	{
		$user_info			= SessionManager::getUserInfo();
		$id					= $this->_getParam('id');
		$name				= $this->_getParam('name');
		$branch_number1		= $this->_getParam('branch_number1');
		$branch_number2     = $this->_getParam('branch_number2');
		$admin_name			= $this->_getParam('admin_name');
		$email				= $this->_getParam('email');
		$param = array("id"=>$id);
		//print_r($this->_getParams());exit;
		$branch_list = Functions::selectFrom($this->_getDBh(), 't_branch', $param);

		$lists = array( 'disp_list'		 => $branch_list,
						'param'			 => $param,
						'search_assign'	 => '');

		$this->_saveDispdata($lists);
		$this->_smarty->assign('branch_list', $branch_list);
		$this->_smarty->assign('id', $branch_list[0]["id"]);
		$this->_smarty->assign('name', $branch_list[0]["name"]);
		$this->_smarty->assign('branch_number1', $branch_list[0]["branch_number1"]);
		$this->_smarty->assign('branch_number2', $branch_list[0]["branch_number2"]);
		$this->_smarty->assign('admin_name', $branch_list[0]["admin_name"]);
		$this->_smarty->assign('email', $branch_list[0]["email"]);
	}

	//sample update action
	public function editAction()
	{
		$user_info			= SessionManager::getUserInfo();
		$id					= $this->_getParam('id');
		$name				= $this->_getParam('name');
		$branch_number1		= $this->_getParam('branch_number1');
		$branch_number2     = $this->_getParam('branch_number2');
		$admin_name			= $this->_getParam('admin_name');
		$email				= $this->_getParam('email');

		$param = array(
				"name"				=>$name
				,"branch_number1"	=>$branch_number1
				,"branch_number2"	=>$branch_number2
				,"admin_name"		=>$admin_name
				,"email"			=>$email
		);
		$where = array(

				  "id"=>$id
		);
		$ret = Functions::updateTo($this->_getDBh(), 't_branch', $param,$where,'0');
		$this->_setupView();
		$this->_forward('index', 'branch-list');
	}

	public function deleteAction()
	{
		$user_info			= SessionManager::getUserInfo();
		$name				= $this->_getParam('name');
		$branch_number1		= $this->_getParam('branch_number1');
		$branch_number2     = $this->_getParam('branch_number2');
		$admin_name			= $this->_getParam('admin_name');
		$email				= $this->_getParam('email');


		// 更新処理
		$param = array(
				"name"				=>$name
				,"branch_number1"	=>$branch_number1
				,"branch_number2"	=>$branch_number2
				,"admin_name"		=>$admin_name
				,"email"			=>$email

		);
		$where = array(

				 "id"=>$id
		);

		$ret = Functions::deleteFrom($this->_getDBh(), 't_branch', $param,$where,'0');
		$this->_forward('index', 'branch-list');
	}
}