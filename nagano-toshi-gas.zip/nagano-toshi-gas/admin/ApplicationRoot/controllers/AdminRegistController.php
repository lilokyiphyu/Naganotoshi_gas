<?php

require_once 'framework/ControllerAbstract.php';
require_once 'helper/SessionManager.php';
require_once 'Exception.php';
require_once 'helper/HtmlTagData.php';


class AdminRegistController extends Framework_ControllerAbstract
{
	private $session = NULL;
	protected function _getValidationSetting() {
		return array('regist' => array('validation_user.ini', 'regist'));
	}

	public function indexAction()
	{
		$this->_setupView();
		$this->_render('AdminRegist');
	}

	private function _setupView()
	{
		$user_info			= SessionManager::getUserInfo();
		$id					= $this->_getParam('id');
		$email				= $this->_getParam('email');
		$param				= array();
		$branch_list		= Functions::selectFrom($this->_getDBh(), 't_branch', $param);

		$lists	= array( 'disp_list'		=> $branch_list,
						 'param'			=> $param,
						 'search_assign'	=> '');

		$this->_smarty->assign('branch_list', $branch_list);
		$this->_smarty->assign('id', $branch_list[0]["id"]);
		$this->_smarty->assign('email', $admin_list[0]["email"]);
		$this->_smarty->assign('select_name', $this->_getParam('branch_name')); //assign the select name
	}

	public function registAction()
	{
		$user_info			= SessionManager::getUserInfo();
		$branch_name		=  $this->_getParam('branch_name');
		$name				=  $this->_getParam('name');
		$email				=  $this->_getParam('email');

		// 登録処理
		$param = array(
				"branch_name"	=>$branch_name
				,"name"			=>$name
				,"email"		=>$email
		);

		$result = Functions::insertTo($this->_getDBh(),'t_admin_user',$param,'0');
		$this->_forward('index','admin-list');
	}
}
